from sqlalchemy.orm import Session
from sqlalchemy import or_
from app.models.task import Task
from app.schemas.task import TaskCreate, TaskUpdate
from app.utils.db_utils import safe_db_operation, handle_db_error
from sqlalchemy.exc import SQLAlchemyError


def get_task(db: Session, task_id: int):
    try:
        return db.query(Task).filter(Task.id == task_id).first()
    except SQLAlchemyError as e:
        handle_db_error(e, "get_task")
        raise


def get_tasks(db: Session, skip: int = 0, limit: int = 100):
    try:
        return db.query(Task).offset(skip).limit(limit).all()
    except SQLAlchemyError as e:
        handle_db_error(e, "get_tasks")
        raise


def create_task(db: Session, task: TaskCreate):
    try:
        db_task = Task(
            title=task.title,
            description=task.description,
            status=task.status,
            priority=task.priority,
            is_important=task.is_important
        )
        db.add(db_task)
        db.commit()
        db.refresh(db_task)
        return db_task
    except SQLAlchemyError as e:
        handle_db_error(e, "create_task")
        raise


def update_task(db: Session, task_id: int, task: TaskUpdate):
    try:
        db_task = db.query(Task).filter(Task.id == task_id).first()
        if db_task:
            # Update only the fields that are provided
            update_data = task.dict(exclude_unset=True)
            for field, value in update_data.items():
                setattr(db_task, field, value)

            db.commit()
            db.refresh(db_task)
        return db_task
    except SQLAlchemyError as e:
        handle_db_error(e, "update_task")
        raise


def delete_task(db: Session, task_id: int):
    try:
        db_task = db.query(Task).filter(Task.id == task_id).first()
        if db_task:
            db.delete(db_task)
            db.commit()
            return True
        return False
    except SQLAlchemyError as e:
        handle_db_error(e, "delete_task")
        raise