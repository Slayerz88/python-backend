from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    database_url: str
    external_api_key: Optional[str] = None
    external_api_url: Optional[str] = None
    debug: bool = False

    class Config:
        env_file = ".env"


settings = Settings()