import pytest
from sqlalchemy import create_engine
from fastapi.testclient import TestClient
from main import app
from app.database.database import engine, Base, get_db
from app.models.task import Task
from sqlalchemy.orm import sessionmaker
from unittest.mock import patch, AsyncMock


# Create a test database
SQLALCHEMY_DATABASE_URL = "sqlite:///./test_api.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


# Dependency override to use test database
def override_get_db():
    database = TestingSessionLocal()
    try:
        yield database
    finally:
        database.close()


app.dependency_overrides[get_db] = override_get_db

client = TestClient(app)


@pytest.fixture(autouse=True)
def setup_and_teardown():
    """Setup and teardown for each test"""
    # Setup: Create all tables
    Base.metadata.create_all(bind=engine)
    yield
    # Teardown: Drop all tables
    Base.metadata.drop_all(bind=engine)


def test_read_root():
    """Test the root endpoint"""
    response = client.get("/")
    assert response.status_code == 200
    assert "message" in response.json()


@patch('app.utils.external_api.get_ai_summary', new_callable=AsyncMock)
def test_create_task(mock_get_summary):
    """Test creating a task"""
    mock_get_summary.return_value = "Mock AI summary"
    
    task_data = {
        "title": "Test Task",
        "description": "This is a test task",
        "status": "pending",
        "priority": "medium",
        "is_important": True
    }
    
    response = client.post("/tasks/", json=task_data)
    assert response.status_code == 201
    
    data = response.json()
    assert data["title"] == "Test Task"
    assert data["description"] == "This is a test task"
    assert data["status"] == "pending"
    assert data["priority"] == "medium"
    assert data["is_important"] is True


@patch('app.utils.external_api.get_ai_summary', new_callable=AsyncMock)
def test_create_task_with_validation_error(mock_get_summary):
    """Test creating a task with invalid data"""
    mock_get_summary.return_value = "Mock AI summary"
    
    task_data = {
        "title": "Test Task",
        "description": "This is a test task",
        "status": "invalid_status",  # Invalid status
        "priority": "medium",
        "is_important": False
    }
    
    response = client.post("/tasks/", json=task_data)
    assert response.status_code == 422  # Validation error


def test_read_task():
    """Test reading a specific task"""
    # First create a task
    task_data = {
        "title": "Test Task",
        "description": "This is a test task",
        "status": "pending",
        "priority": "medium",
        "is_important": False
    }
    
    create_response = client.post("/tasks/", json=task_data)
    assert create_response.status_code == 201
    
    created_task = create_response.json()
    task_id = created_task["id"]
    
    # Now read the task
    response = client.get(f"/tasks/{task_id}")
    assert response.status_code == 200
    
    data = response.json()
    assert data["id"] == task_id
    assert data["title"] == "Test Task"


def test_read_nonexistent_task():
    """Test reading a task that doesn't exist"""
    response = client.get("/tasks/99999")
    assert response.status_code == 404


@patch('app.utils.external_api.get_ai_summary', new_callable=AsyncMock)
def test_update_task(mock_get_summary):
    """Test updating a task"""
    mock_get_summary.return_value = "Mock AI summary"
    
    # First create a task
    task_data = {
        "title": "Original Task",
        "description": "Original description",
        "status": "pending",
        "priority": "medium",
        "is_important": False
    }
    
    create_response = client.post("/tasks/", json=task_data)
    assert create_response.status_code == 201
    
    created_task = create_response.json()
    task_id = created_task["id"]
    
    # Now update the task
    update_data = {
        "title": "Updated Task",
        "description": "Updated description",
        "status": "completed",
        "priority": "high",
        "is_important": True
    }
    
    response = client.put(f"/tasks/{task_id}", json=update_data)
    assert response.status_code == 200
    
    data = response.json()
    assert data["title"] == "Updated Task"
    assert data["description"] == "Updated description"
    assert data["status"] == "completed"
    assert data["priority"] == "high"
    assert data["is_important"] is True


def test_update_nonexistent_task():
    """Test updating a task that doesn't exist"""
    update_data = {
        "title": "Updated Task",
        "description": "Updated description",
        "status": "completed",
        "priority": "high",
        "is_important": True
    }
    
    response = client.put("/tasks/99999", json=update_data)
    assert response.status_code == 404


def test_delete_task():
    """Test deleting a task"""
    # First create a task
    task_data = {
        "title": "Task to Delete",
        "description": "This task will be deleted",
        "status": "pending",
        "priority": "medium",
        "is_important": False
    }
    
    create_response = client.post("/tasks/", json=task_data)
    assert create_response.status_code == 201
    
    created_task = create_response.json()
    task_id = created_task["id"]
    
    # Verify task exists
    get_response = client.get(f"/tasks/{task_id}")
    assert get_response.status_code == 200
    
    # Now delete the task
    response = client.delete(f"/tasks/{task_id}")
    assert response.status_code == 200
    
    # Verify task is deleted
    get_response = client.get(f"/tasks/{task_id}")
    assert get_response.status_code == 404


def test_delete_nonexistent_task():
    """Test deleting a task that doesn't exist"""
    response = client.delete("/tasks/99999")
    assert response.status_code == 404


def test_read_tasks():
    """Test reading multiple tasks"""
    # Create multiple tasks
    tasks = [
        {
            "title": "Task 1",
            "description": "First task",
            "status": "pending",
            "priority": "low",
            "is_important": False
        },
        {
            "title": "Task 2",
            "description": "Second task",
            "status": "in_progress",
            "priority": "medium",
            "is_important": True
        }
    ]
    
    for task in tasks:
        response = client.post("/tasks/", json=task)
        assert response.status_code == 201
    
    # Read all tasks
    response = client.get("/tasks/")
    assert response.status_code == 200
    
    data = response.json()
    assert len(data) >= 2
    
    titles = [task["title"] for task in data]
    assert "Task 1" in titles
    assert "Task 2" in titles