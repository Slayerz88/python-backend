import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.database.database import Base
from app.api import crud
from app.schemas.task import TaskCreate, TaskUpdate


# Create a test database
SQLALCHEMY_DATABASE_URL = "sqlite:///./test.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


@pytest.fixture
def db():
    """Create a test database session"""
    Base.metadata.create_all(bind=engine)
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()
        Base.metadata.drop_all(bind=engine)


def test_create_task(db):
    """Test creating a task"""
    task_data = TaskCreate(
        title="Test Task",
        description="This is a test task",
        status="pending",
        priority="medium",
        is_important=True
    )
    
    created_task = crud.create_task(db=db, task=task_data)
    
    assert created_task.title == "Test Task"
    assert created_task.description == "This is a test task"
    assert created_task.status == "pending"
    assert created_task.priority == "medium"
    assert created_task.is_important is True
    assert created_task.id is not None


def test_get_task(db):
    """Test retrieving a task"""
    # First create a task
    task_data = TaskCreate(
        title="Test Task",
        description="This is a test task",
        status="pending",
        priority="medium",
        is_important=False
    )
    created_task = crud.create_task(db=db, task=task_data)
    
    # Then retrieve it
    retrieved_task = crud.get_task(db=db, task_id=created_task.id)
    
    assert retrieved_task.id == created_task.id
    assert retrieved_task.title == created_task.title
    assert retrieved_task.description == created_task.description


def test_get_tasks(db):
    """Test retrieving multiple tasks"""
    # Create multiple tasks
    task_data1 = TaskCreate(
        title="Test Task 1",
        description="First test task",
        status="pending",
        priority="medium",
        is_important=False
    )
    task_data2 = TaskCreate(
        title="Test Task 2",
        description="Second test task",
        status="in_progress",
        priority="high",
        is_important=True
    )
    
    crud.create_task(db=db, task=task_data1)
    crud.create_task(db=db, task=task_data2)
    
    # Retrieve all tasks
    tasks = crud.get_tasks(db=db, skip=0, limit=10)
    
    assert len(tasks) >= 2
    titles = [task.title for task in tasks]
    assert "Test Task 1" in titles
    assert "Test Task 2" in titles


def test_update_task(db):
    """Test updating a task"""
    # Create a task first
    task_data = TaskCreate(
        title="Original Task",
        description="Original description",
        status="pending",
        priority="medium",
        is_important=False
    )
    created_task = crud.create_task(db=db, task=task_data)
    
    # Update the task
    update_data = TaskUpdate(
        title="Updated Task",
        description="Updated description",
        status="completed",
        priority="high",
        is_important=True
    )
    
    updated_task = crud.update_task(db=db, task_id=created_task.id, task=update_data)
    
    assert updated_task.title == "Updated Task"
    assert updated_task.description == "Updated description"
    assert updated_task.status == "completed"
    assert updated_task.priority == "high"
    assert updated_task.is_important is True


def test_delete_task(db):
    """Test deleting a task"""
    # Create a task first
    task_data = TaskCreate(
        title="Task to Delete",
        description="This task will be deleted",
        status="pending",
        priority="low",
        is_important=False
    )
    created_task = crud.create_task(db=db, task=task_data)
    
    # Verify task exists
    retrieved_task = crud.get_task(db=db, task_id=created_task.id)
    assert retrieved_task is not None
    
    # Delete the task
    success = crud.delete_task(db=db, task_id=created_task.id)
    assert success is True
    
    # Verify task is deleted
    deleted_task = crud.get_task(db=db, task_id=created_task.id)
    assert deleted_task is None


def test_delete_nonexistent_task(db):
    """Test deleting a task that doesn't exist"""
    success = crud.delete_task(db=db, task_id=99999)
    assert success is False