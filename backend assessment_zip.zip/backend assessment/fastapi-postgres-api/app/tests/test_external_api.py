import pytest
from unittest.mock import AsyncMock, patch
from app.utils.external_api import get_ai_summary


@pytest.mark.asyncio
async def test_get_ai_summary_with_external_api():
    """Test the AI summary function with mocked external API"""
    title = "Test Task"
    description = "This is a test task description"
    
    with patch('app.utils.external_api.settings') as mock_settings:
        mock_settings.external_api_url = "https://api.example.com"
        mock_settings.external_api_key = "test-key"
        
        result = await get_ai_summary(title, description)
        assert "AI Summary" in result or "Summary for" in result
        assert title[:30] in result


@pytest.mark.asyncio
async def test_get_ai_summary_without_external_api():
    """Test the AI summary function when no external API is configured"""
    title = "Test Task"
    
    with patch('app.utils.external_api.settings') as mock_settings:
        mock_settings.external_api_url = None
        mock_settings.external_api_key = None
        
        result = await get_ai_summary(title)
        assert "Summary for" in result
        assert title[:30] in result


@pytest.mark.asyncio
async def test_get_ai_summary_with_error():
    """Test the AI summary function when external API call fails"""
    title = "Test Task"
    
    with patch('app.utils.external_api.settings') as mock_settings, \
         patch('asyncio.sleep', new=AsyncMock(side_effect=Exception("API Error"))):
        mock_settings.external_api_url = "https://api.example.com"
        mock_settings.external_api_key = "test-key"
        
        result = await get_ai_summary(title)
        # Should return fallback summary
        assert "Summary for" in result or "AI summary" in result