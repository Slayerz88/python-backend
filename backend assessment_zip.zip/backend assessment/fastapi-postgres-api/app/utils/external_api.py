import httpx
import asyncio
from app.database.config import settings
from typing import Optional


async def get_ai_summary(title: str, description: Optional[str] = None) -> str:
    """
    Function that simulates calling an external AI API to generate a summary.
    In a real implementation, this would call an actual LLM service like OpenAI.
    For this example, we'll simulate the API call with a mock response.
    """
    # In a real implementation, we would make an actual API call here
    # For the demo, let's simulate with a mock response
    
    if settings.external_api_url and settings.external_api_key:
        # Real implementation would make an HTTP call to the external service
        try:
            # Simulate API call delay
            await asyncio.sleep(1)
            
            # In a real implementation, we would use httpx to make the actual call
            # async with httpx.AsyncClient() as client:
            #     response = await client.post(
            #         settings.external_api_url,
            #         headers={"Authorization": f"Bearer {settings.external_api_key}"},
            #         json={
            #             "prompt": f"Summarize this task: {title}. Description: {description or 'No description provided.'}",
            #             "max_tokens": 100
            #         },
            #         timeout=10.0
            #     )
            #     if response.status_code == 200:
            #         result = response.json()
            #         return result.get("summary", f"AI summary for task: {title[:50]}...")
            
            # For demo purposes, return a mock summary
            return f"AI Summary: This is an important task titled '{title[:30]}...' that requires attention and completion."
        except Exception as e:
            # Log the error in a real implementation
            print(f"Error calling external API: {str(e)}")
            # Return a fallback summary
            return f"Summary for '{title[:30]}...': Important task requiring attention."
    else:
        # Return a mock summary if no external API is configured
        return f"Summary for '{title[:30]}...': Important task requiring attention."