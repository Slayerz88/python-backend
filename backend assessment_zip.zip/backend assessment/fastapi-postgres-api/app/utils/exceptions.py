from fastapi import Request, FastAPI
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException
from typing import Union


class TaskException(Exception):
    def __init__(self, message: str, error_code: str = None):
        self.message = message
        self.error_code = error_code
        super().__init__(self.message)


async def task_exception_handler(request: Request, exc: TaskException):
    return JSONResponse(
        status_code=400,
        content={
            "success": False,
            "message": exc.message,
            "error_code": exc.error_code
        }
    )


async def http_exception_handler(request: Request, exc: StarletteHTTPException):
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "success": False,
            "message": exc.detail,
            "error_code": f"HTTP_{exc.status_code}"
        }
    )


async def validation_exception_handler(request: Request, exc: RequestValidationError):
    # Convert errors to a JSON-serializable format
    error_details = []
    for error in exc.errors():
        # Convert 'ctx' which contains non-serializable objects to strings
        error_copy = error.copy()
        if 'ctx' in error_copy:
            ctx_copy = {}
            for key, value in error_copy['ctx'].items():
                if hasattr(value, '__dict__'):
                    ctx_copy[key] = str(value)
                else:
                    ctx_copy[key] = value
            error_copy['ctx'] = ctx_copy
        error_details.append(error_copy)

    return JSONResponse(
        status_code=422,
        content={
            "success": False,
            "message": "Validation error",
            "error_code": "VALIDATION_ERROR",
            "details": error_details
        }
    )


async def general_exception_handler(request: Request, exc: Exception):
    return JSONResponse(
        status_code=500,
        content={
            "success": False,
            "message": "Internal server error",
            "error_code": "INTERNAL_ERROR"
        }
    )


def add_exception_handlers(app: FastAPI):
    app.add_exception_handler(TaskException, task_exception_handler)
    app.add_exception_handler(StarletteHTTPException, http_exception_handler)
    app.add_exception_handler(RequestValidationError, validation_exception_handler)
    app.add_exception_handler(Exception, general_exception_handler)