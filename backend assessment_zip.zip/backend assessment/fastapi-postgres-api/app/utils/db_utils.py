from sqlalchemy.exc import SQLAlchemyError
from fastapi import HTTPException, status
from typing import Callable, Any
import logging

logger = logging.getLogger(__name__)


def handle_db_error(error: SQLAlchemyError, operation: str = "database operation"):
    """
    General function to handle database errors
    """
    logger.error(f"Database error during {operation}: {str(error)}")
    raise HTTPException(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        detail=f"Database error during {operation}: {str(error)}"
    )


def safe_db_operation(func: Callable) -> Callable:
    """
    Decorator to wrap database operations with error handling
    """
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except SQLAlchemyError as e:
            handle_db_error(e, func.__name__)
        except Exception as e:
            logger.error(f"Unexpected error in {func.__name__}: {str(e)}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Unexpected error: {str(e)}"
            )
    return wrapper