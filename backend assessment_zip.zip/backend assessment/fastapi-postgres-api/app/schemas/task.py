from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime


class TaskBase(BaseModel):
    title: str
    description: Optional[str] = None
    status: Optional[str] = "pending"
    priority: Optional[str] = "medium"
    is_important: Optional[bool] = False

    @validator('status')
    def validate_status(cls, v):
        if v not in ['pending', 'in_progress', 'completed']:
            raise ValueError('status must be pending, in_progress, or completed')
        return v

    @validator('priority')
    def validate_priority(cls, v):
        if v not in ['low', 'medium', 'high']:
            raise ValueError('priority must be low, medium, or high')
        return v


class TaskCreate(TaskBase):
    title: str  # Title is required for creation


class TaskUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    status: Optional[str] = None
    priority: Optional[str] = None
    is_important: Optional[bool] = None

    @validator('status')
    def validate_status(cls, v):
        if v is not None and v not in ['pending', 'in_progress', 'completed']:
            raise ValueError('status must be pending, in_progress, or completed')
        return v

    @validator('priority')
    def validate_priority(cls, v):
        if v is not None and v not in ['low', 'medium', 'high']:
            raise ValueError('priority must be low, medium, or high')
        return v


class Task(TaskBase):
    id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    summary: Optional[str] = None

    class Config:
        from_attributes = True