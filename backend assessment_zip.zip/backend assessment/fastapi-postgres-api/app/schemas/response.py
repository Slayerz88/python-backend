from pydantic import BaseModel
from typing import Optional


class SuccessResponse(BaseModel):
    success: bool
    message: str
    data: Optional[dict] = None


class ErrorResponse(BaseModel):
    success: bool
    message: str
    error_code: Optional[str] = None